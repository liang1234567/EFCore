﻿using Asp.NetCore.EFCore.Models.Migrations;
using System;

namespace Asp.NetCore.EFCore.ConsoleShow
{
    class Program
    {
        static void Main(string[] args)
        {
            EFCoreMigrationContext context = new EFCoreMigrationContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            Console.ReadLine();
        }
    }
}
