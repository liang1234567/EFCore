﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Asp.NetCore.EFCore.ConsoleShow
{
    public class QueryTest
    {
        public static void Show()
        {





        }


    }
}
