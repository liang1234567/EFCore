﻿using Asp.NetCore.EFCore.Models.Migrations.models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Asp.NetCore.EFCore.Models;

namespace Asp.NetCore.EFCore.Models.Migrations
{
    /// <summary>
    /// 迁移的Context
    /// </summary>
    public class EFCoreMigrationContext:DbContext
    {
        private string strConn = "Server=DESKTOP-IAT6RTO;Database=EFCore01;Trusted_Connection=True;";
        public DbSet<SysUserInfo> SysUserInfo { get; set; }
        public DbSet<Company> Company { get; set; }
        public DbSet<SysUserInfoDetail> SysUserInfoDetail { get; set; }
        public DbSet<SysUserRoleMapping> SysUserRoleMapping { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(strConn);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SysUserInfo>().HasData(new SysUserInfo()
            {
                Name = "刘晓管",
                Password = "123456",
                Status = 1,
                Phone = "10086",
                Mobile = "10010",
                Address = "北京指挥部",
                Email = "10026@qq.com",
                QQ = 1123456,
                WeChat = "186489713",
                Sex = 1,
                LastLoginTime = DateTime.Now,
                CreateTime = DateTime.Now,
                CreateId = 1,
                LastModifyId = 1,
                LastModifyTime = DateTime.Now,
                Id=1
            }) ;
            modelBuilder.Entity<SysUserInfo>().HasOne(u => u.SysUserInfoDetail).WithOne().HasForeignKey<SysUserInfoDetail>(a=>a.SysUserInfoDetailId);
            modelBuilder.Entity<SysUserInfo>().HasOne(u => u.Company).WithMany(u => u.SysUsers).HasForeignKey(a => a.CompanyId);
            modelBuilder.Entity<SysUserRoleMapping>().HasOne(p => p.SysUserInfo).WithMany(u => u.SysUserRoleMapping).HasForeignKey(u => u.SysUserId);
            modelBuilder.Entity<SysUserRoleMapping>().HasOne(p => p.SysRole).WithMany(r => r.SysUserRoleMappings).HasForeignKey(s => s.SysRoleId);
            //联合主键
            modelBuilder.Entity<SysUserRoleMapping>().HasKey(p => new { p.SysUserId, p.SysRoleId });
            # region 索引
            modelBuilder.Entity<SysUserInfo>().HasIndex(a => new { a.Name, a.Phone });
            modelBuilder.Entity<SysRole>().HasIndex(u => u.Name).IsUnique();
            modelBuilder.Entity<SysUserInfo>().HasIndex(a => new { a.Name, a.Phone });


            #endregion



        }


    }
}
