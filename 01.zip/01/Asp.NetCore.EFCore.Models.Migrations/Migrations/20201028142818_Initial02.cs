﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Asp.NetCore.EFCore.Models.Migrations.Migrations
{
    public partial class Initial02 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "SysUserInfo",
                columns: new[] { "Id", "Address", "CompanyId", "CreateId", "CreateTime", "Email", "LastLoginTime", "LastModifyId", "LastModifyTime", "Mobile", "Name", "Password", "Phone", "QQ", "Sex", "Status", "WeChat" },
                values: new object[] { 1, "北京指挥部", 0, 1, new DateTime(2020, 10, 28, 22, 28, 18, 369, DateTimeKind.Local).AddTicks(9233), "10026@qq.com", new DateTime(2020, 10, 28, 22, 28, 18, 366, DateTimeKind.Local).AddTicks(8778), 1, new DateTime(2020, 10, 28, 22, 28, 18, 370, DateTimeKind.Local).AddTicks(3186), "10010", "刘晓管", "123456", "10086", 1123456L, (byte)1, (byte)1, "186489713" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "SysUserInfo",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
