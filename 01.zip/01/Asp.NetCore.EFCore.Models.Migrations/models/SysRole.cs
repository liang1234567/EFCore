﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Asp.NetCore.EFCore.Models.Migrations.models
{
    [Table("SysRole")]

    public class SysRole
    {
        public int Id { get; set; }
        [Required]
        [StringLength(36)]
        public string Name { get; set; }
        [StringLength(100)]
        public string Description { get; set; }
        public byte Status { get; set; }
        public DateTime CreateTime { get; set; }
        public int CreateId { get; set; }
        public DateTime? LastModifyTime { get; set; }
        public int? LastModifierId{get;set;}
        public List<SysUserRoleMapping> SysUserRoleMappings { get; set; }
    }
}
