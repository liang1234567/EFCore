﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Asp.NetCore.EFCore.Models.Migrations.models
{
    [Table("SysUserInfoDetail")]
    public partial class SysUserInfoDetail
    {
        [Key]
        public int Id { get; set; }
        public int SysUserInfoDetailId { get; set; }
        public string Description { get; set; }
        public SysUserInfo SysUserInfo { get; set; }
    }
}
