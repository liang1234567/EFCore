﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Asp.NetCore.EFCore.Models.Migrations.models
{
    [Table("SysUserRoleMapping")]
    public class SysUserRoleMapping
    {
        public int Id { get; set; }
        public int SysUserId { get; set; }

        public SysUserInfo SysUserInfo { get; set; }
        public SysRole SysRole { get; set; }
        public int SysRoleId { get; set; }




    }
}
