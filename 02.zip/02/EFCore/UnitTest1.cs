using ClassLibrary1;
using NUnit.Framework;

namespace EFCore
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            EFCoreContextWrite01 context = new EFCoreContextWrite01();
            context.Database.EnsureDeleted();//ɾ�����ݿ�
            context.Database.EnsureCreated();//�½����ݿ�
            //Assert.Pass();
        }
    }
}