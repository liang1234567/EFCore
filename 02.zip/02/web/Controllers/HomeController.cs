﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ClassLibrary1;
using ClassLibrary1.Extend;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using web.Models;

namespace web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IDbContextFactory _DbContextFactory;



        public HomeController(ILogger<HomeController> logger,IDbContextFactory dbContext)
        {
            _logger = logger;
            _DbContextFactory = dbContext;
        }

        public IActionResult Index()
        {
    
            {
                var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json").Build();
                IDbContextFactory dbContextFactory = new DbContextFactory(configuration);

                {
                    EFCoreDataContext context = dbContextFactory.CreateDbContext(WriteAndRead.Write);
                    context.UserInfo.Add(new UserInfo()
                    {

                        UserName = "小九",
                        UserAge = 25,
                        Description = "山东大学学生"

                    });
                    context.SaveChanges();
                }
                {
                    EFCoreDataContext context = dbContextFactory.CreateDbContext(WriteAndRead.Read);
                    UserInfo user = context.UserInfo.OrderByDescending(a => a.UserId).FirstOrDefault();
                }
            }
            {

                {
                    EFCoreDataContext context1 = _DbContextFactory.CreateDbContext(WriteAndRead.Write);
                    context1.UserInfo.Add(new UserInfo()
                    {

                        UserName = "小吧",
                        UserAge = 25,
                        Description = "山东大学学生"

                    });
                    context1.SaveChanges();
                }
                {
                    EFCoreDataContext context2 = _DbContextFactory.CreateDbContext(WriteAndRead.Read);
                    UserInfo user = context2.UserInfo.OrderByDescending(a => a.UserId).FirstOrDefault();
                }
            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
