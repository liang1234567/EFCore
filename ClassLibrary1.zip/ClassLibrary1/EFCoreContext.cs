﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace ClassLibrary1
{
    public class EFCoreContext:DbContext
    {
        private string strConn = "Server=DESKTOP-IAT6RTO;Database=EFCore;Trusted_Connection=True;";
        public DbSet<UserInfo> UserInfo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(strConn);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserInfo>().HasData(new List<UserInfo>(){
                new UserInfo()
                {
                    UserId = 1,
                    UserName = "Mr.li",
                    Description = "微软教育工作者",
                    UserAge = 36
                },
                 new UserInfo()
                 {
                     UserId = 2,
                     UserName = "Mr.liu",
                     Description = "微软教育工作者",
                     UserAge = 36
                 },
                 new UserInfo()
                 {
                     UserId = 3,
                     UserName = "Mr.wang",
                     Description = "廿书教育工作者",
                     UserAge = 23
                 }
            });
        }
    }
}
