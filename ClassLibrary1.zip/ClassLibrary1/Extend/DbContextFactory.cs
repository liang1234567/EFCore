﻿using ClassLibrary1.Extend;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{
    public class DbContextFactory:IDbContextFactory
    {
        private IConfiguration _Configulation;
        private string[] ReadConn = null;
        public DbContextFactory(IConfiguration configulation)
        {
            _Configulation = configulation;
            ReadConn = _Configulation.GetConnectionString("ReadAspNetCoreDataBase").Split(",".ToCharArray());
        }
        /// <summary>
        /// 配置文件
        /// </summary>
        /// <returns></returns>

        public EFCoreDataContext CreateDbContext(WriteAndRead writeAndRead)
        {
            string conn = string.Empty;
            switch (writeAndRead)
            {
                case WriteAndRead.Write:
                    conn = _Configulation.GetConnectionString("WriteAspNetCoreDataBase");
                    break;
                case WriteAndRead.Read:
                    conn = _Configulation.GetConnectionString("ReadAspNetCoreDataBase");
                    break;
                default: 
                    break;
            }
            return new EFCoreDataContext(conn);
        }
        /// <summary>
        /// 随机分配数据库
        /// </summary>
        /// <returns></returns>
        private string GetReadConn()
        {
            string conn = null;
            int index=new Random().Next(0,ReadConn.Length-1);
            conn = ReadConn[index];
            return conn; 
        }

    }
}
