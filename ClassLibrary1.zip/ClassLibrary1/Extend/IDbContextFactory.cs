﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.Extend
{
    public interface IDbContextFactory
    {
        EFCoreDataContext CreateDbContext(WriteAndRead writeAndRead);
    }
}
