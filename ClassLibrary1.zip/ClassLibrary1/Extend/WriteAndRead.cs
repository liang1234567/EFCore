﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.Extend
{
    public enum WriteAndRead
    {
        Write,
        Read
    }
    public enum QueryDBStrategyEnum
    {
        Random,
        Polling
    }

}
